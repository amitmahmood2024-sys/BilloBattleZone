const App = {
  init() {
    console.log("Billo Battle Zone initialized");
  }
};

document.addEventListener("DOMContentLoaded", App.init);