function qs(id) {
  return document.getElementById(id);
}

function show(el) {
  el.style.display = "block";
}

function hide(el) {
  el.style.display = "none";
}